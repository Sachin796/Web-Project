$(document).keyup(function (e) {
    if ($("#comments").is(":focus") && (e.keyCode == 13)) {
        addComments();
    }
});