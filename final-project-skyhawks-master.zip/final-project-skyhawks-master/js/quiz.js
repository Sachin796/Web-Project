
    console.log("in js fie");
$(document).ready(function () {
    $('label').click(function(){
        console.log('in label');
        $('input[type = radio]:checked + label').removeClass('correct');
        $('label').removeClass('incorrect');
        $(this).addClass('incorrect');	
    });
    $('label#one').click
	(function(){
        console.log('in label#one');                                        //determines in console that we have entered inside the label#one function
       $('label').removeClass('incorrect');
		$(this).addClass('correct');
		
	}
	);

   
});
