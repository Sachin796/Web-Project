Final project web pages Description

Home Page
Javascript used for sliding of images and changing images automatically
Json used to send data in the div tag using jquery

News page
Json used to send data using jquery

Registration page
Form is validated using javascript
Data is stored in localstorage