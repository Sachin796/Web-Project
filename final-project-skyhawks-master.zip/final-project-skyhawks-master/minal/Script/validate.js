//This Code is to validate all the text values
    var $ = function (id)
    {
        return document.getElementById(id);
    };

    function validateemail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
    console.log(email);
  }

     function registerbtn()
        {
            var fname = document.getElementById("fname").value;
            var lname = document.getElementById("lname").value;
            var email = document.getElementById("email1").value;
            var password = document.getElementById("passwords").value;
            var countryOptions = document.getElementById("selectedCountry");
            var country = countryOptions.options[countryOptions.selectedIndex].text;
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            var pattern =/^[a-zA-Z]{2,30}$/;
            console.log(email);
            var b= re.test(email);
            console.log(b);

        if(fname == "")
        {
            alert('Enter First Name');
        }
        else if(!pattern.test(fname))
        {
           alert('Enter valid First Name');
        }
        else if(!pattern.test(lname))
        {
                alert('Enter Last Name');
        }

        else if(!b)
        {
            alert('Enter Correct email ID');
        }

        else if(password == "")
        {
            alert('Enter Password');
        }

        else
        {
            alert('Registered successfully');
            localStorage.setItem("fname",fname);
            localStorage.setItem("lname",lname);
            localStorage.setItem("email1",email);
            localStorage.setItem("password",password);
            localStorage.setItem("country",country);
            var fname=localStorage.getItem("fname");
            var lname=localStorage.getItem("lname");
            var email=localStorage.getItem("email1");
            var password=localStorage.getItem("password");
            var country=localStorage.getItem("country");
            console.log("Name : ",fname,lname,"Email-Id : ",email, "Password : ",password, "Country : ",country);
            document.getElementById('fname').value = '';
            document.getElementById('lname').value = '';
            document.getElementById('email1').value = '';
            document.getElementById('passwords').value = '';
        }
}


