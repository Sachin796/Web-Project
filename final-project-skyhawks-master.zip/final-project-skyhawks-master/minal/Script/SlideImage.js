//This file is for changing the images using button or slide show of images
var myImagesArray = ["Images/Home/1.jpg","Images/Home/Image2.jpg","Images/Home/Image8.jpg","Images/Home/Image7.jpg","Images/Home/Image3.jpg","Images/Home/9.jpg","Images/Home/4.jpg","Images/Home/Image1.jpg","Images/Home/Image4.jpg","Images/Home/Image5.png"];

    var ImageNumber = 0;
    var difference = myImagesArray.length - 1;
    var delay = 3000; //milliseconds    1sec=1000milliseconds
   	setInterval("ChangeImage(-1)", delay);
    function ChangeImage(direction)
    {//begin function
       
            ImageNumber = ImageNumber + direction;
            if(ImageNumber > difference)
            {//begin first inner if
                ImageNumber = 0;
            }//end first if
            if(ImageNumber < 0)
            {//begin second inner if
                ImageNumber = difference;
            }//end second if

            document.getElementById('slideshow').src= myImagesArray[ImageNumber];
        
    }//end

//For setting value of news in json
    $(document).ready(function () {
			        $.getJSON('data.json', function (data) {
			            var result=""; 	
			            console.log(data);
			            $.each(data.content, function (index, datas) {  
			                result += "<li> " + datas.li + " </li>";
			            });
			            $('#result').html(result);
			        }); // end getJSON
			    }); //