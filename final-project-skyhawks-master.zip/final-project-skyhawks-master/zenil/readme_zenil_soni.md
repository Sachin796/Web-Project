Name: Zenil Soni

Pages: Brands.html
       About Us.html
       Reviews.html 

Brands

--> Dropdown button in Navigation bar.
--> Redirect to review.html
--> Responsive

Reviews

--> Slideshow of images
--> Display contents about phone
-->Add reviews via javascript

About US

-->Css
-->Responsive