Name- Sachin Jhaveri

Pages
1. FAQ- The Faq page consists of all the frequently aske questions . Its uses javascript for animation of dropdown and a side bar for navigation.The sidebar will have inpage navigation and t a responsive page .

2. Search page- The seach page is used to search the smartphones according to the contents written in the search text.The page also includes navigation to all the othe pages.

3. Quiz- Quiz page consists of all the quiz questions .